import "regenerator-runtime";
import "./styles/style.css";
import "./scripts/components/app-bar.js";
import main from "./scripts/view/main.js";

document.addEventListener("DOMContentLoaded", main);
