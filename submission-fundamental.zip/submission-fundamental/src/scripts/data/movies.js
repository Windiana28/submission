const movies = [
  {
    Judul: "Crazy, Stupid, Love.",
    Tahun: "2011",
    fanArt: "https://m.media-amazon.com/images/M/MV5BMTg2MjkwMTM0NF5BMl5BanBnXkFtZTcwMzc4NDg2NQ@@._V1_SX300.jpg",
  },
  {
    Judul: "Dr. Strangelove or: How I Learned to Stop Worrying and Love the Bomb",
    Tahun: "1964",
    fanArt: "https://m.media-amazon.com/images/M/MV5BZWI3ZTMxNjctMjdlNS00NmUwLWFiM2YtZDUyY2I3N2MxYTE0XkEyXkFqcGdeQXVyNzkwMjQ5NzM@._V1_SX300.jpg",
  },
  {
    Judul: "Love Actually",
    Tahun: "2003",
    fanArt: "https://m.media-amazon.com/images/M/MV5BMTY4NjQ5NDc0Nl5BMl5BanBnXkFtZTYwNjk5NDM3._V1_SX300.jpg",
  },
  {
    Judul: "Shakespeare in Love",
    Tahun: "1998",
    fanArt: "https://m.media-amazon.com/images/M/MV5BM2ZkNjM5MjEtNTBlMC00OTI5LTgyYmEtZDljMzNmNzhiNzY0XkEyXkFqcGdeQXVyNDYyMDk5MTU@._V1_SX300.jpg",
  },
  {
    Judul: "P.S. I Love You",
    Tahun: "2007",
    fanArt: "https://m.media-amazon.com/images/M/MV5BNTg2MDg4MjI5NV5BMl5BanBnXkFtZTcwMzQ0MDczMw@@._V1_SX300.jpg",
  },
  {
    Judul: "I Love You, Man",
    Tahun: "2009",
    fanArt: "https://m.media-amazon.com/images/M/MV5BMTU4MjI5NTEyNV5BMl5BanBnXkFtZTcwNjQ1NTMzMg@@._V1_SX300.jpg",
  },
  {
    Judul: "Love & Other Drugs",
    Tahun: "2010",
    fanArt: "https://m.media-amazon.com/images/M/MV5BMTgxOTczODEyMF5BMl5BanBnXkFtZTcwMDc0NDY4Mw@@._V1_SX300.jpg",
  },
  {
    Judul: "Punch-Drunk Love",
    Tahun: "2002",
    fanArt: "https://m.media-amazon.com/images/M/MV5BYmE1OTY4NjgtYjcwNC00NWE4LWJiNGMtZmVhYTdlMWE1YzIxXkEyXkFqcGdeQXVyMTMxODk2OTU@._V1_SX300.jpg",
  },
  {
    Judul: "In the Mood for Love",
    Tahun: "2000",
    fanArt: "https://m.media-amazon.com/images/M/MV5BYjZjODRlMjQtMjJlYy00ZDBjLTkyYTQtZGQxZTk5NzJhYmNmXkEyXkFqcGdeQXVyMTQxNzMzNDI@._V1_SX300.jpg",
  },
  {
    Judul: "Love, Rosie",
    Tahun: "2014",
    fanArt: "https://m.media-amazon.com/images/M/MV5BMTk0Mzg1MTU1MF5BMl5BanBnXkFtZTgwMjU3ODI2MzE@._V1_SX300.jpg",
  },
];

export default movies;
